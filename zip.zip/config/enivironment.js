const development = {
    name:'development',
    asset_path:'/assets'
}

const production = {
    name: 'production'
}


module.exports = development;