const post = require("../models/post");
const user = require("../models/user"); 
const Friends = require("../models/friends");
module.exports.home = async function(req,res){
    try{
        let postData = await post.find({})
        .sort("-createdAt")
        .populate('user')
        .populate({
            path:'comments',
            populate:{
                path:'likes'
            },
            populate:{
                path:'user',
            },
        }).populate('likes');
        let userData = {};
        let followerData = {}
        if(req.user !== undefined){
            userData = await user.find({});
            followerData = await user.findById(req.user.id).populate('friends');
            console.log(followerData);
        }
        // if(userData.length > 0){
        //     userData = userData.filter((user)=>{
        //         return user.id != req.user.id;
        //     });
        //     PUK = userData.filter((user)=>{
        //         followerData.find(d=> d._id !== user._id);
        //     });
        //     console.log(PUK)
        // }
         
         
        console.log(followerData);
        return res.render('home',{
            title:'Hemanthify Feed',
            posts:postData,
            users:userData,
            followers:followerData
        });

    }catch(err){
        console.log(err);
        return;
    }
    
     
}

// (common syntax)module.exports.action = function(req,res)